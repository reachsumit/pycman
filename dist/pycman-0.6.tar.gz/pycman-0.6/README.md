Simple Pacman game simulator in Python

This is a simple Pacman game simulator in Python.