Simple Pacman game simulator in Python

This is a simple Pacman game simulator in Python.

### Compilation Instructions:
python setup.py develop  
python setup.py sdist bdist_wheel  
twine upload dist/*  
  
pip install --no-cache-dir --upgrade pycman  
